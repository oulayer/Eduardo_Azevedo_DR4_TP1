using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Questão3.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
