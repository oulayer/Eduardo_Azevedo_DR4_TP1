using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Questao7.Pages.CountryManager
{
    public class CreateCountriesModel : PageModel
    {
        public class InputModel
        {
            public string CountryName { get; set; } = "";
            public string CountryCode { get; set; } = "";
        }

        [BindProperty]
        public List<InputModel> Countries { get; set; } = new();

        public List<InputModel>? SubmittedCountries { get; set; }

        public void OnGet()
        {
            for (int i = 0; i < 5; i++)
            {
                Countries.Add(new InputModel());
            }
        }

        public void OnPost()
        {
            SubmittedCountries = Countries;
        }
    }
}