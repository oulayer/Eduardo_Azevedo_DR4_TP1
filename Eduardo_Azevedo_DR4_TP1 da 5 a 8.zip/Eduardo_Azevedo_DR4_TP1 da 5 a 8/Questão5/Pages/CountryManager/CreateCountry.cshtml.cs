using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Questao5.Models;

namespace Questao5.Pages.CountryManager
{
    public class CreateCountryModel : PageModel
    {
        public class InputModel
        {
            public string CountryName { get; set; } = "";
            public string CountryCode { get; set; } = "";
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public Country? CreatedCountry { get; set; }

        public void OnGet()
        {
        }

        public void OnPost()
        {
            CreatedCountry = new Country
            {
                CountryName = Input.CountryName,
                CountryCode = Input.CountryCode
            };
        }
    }
}