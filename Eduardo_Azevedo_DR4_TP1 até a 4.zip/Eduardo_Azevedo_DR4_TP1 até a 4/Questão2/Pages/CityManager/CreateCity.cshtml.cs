using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Questao2.Pages.CityManager
{
    public class CreateCityModel : PageModel
    {
        public string SubmittedCityName { get; set; } = "";

        public void OnGet()
        {
        }

        public void OnPost(string cityName)
        {
            SubmittedCityName = cityName;
        }
    }
}