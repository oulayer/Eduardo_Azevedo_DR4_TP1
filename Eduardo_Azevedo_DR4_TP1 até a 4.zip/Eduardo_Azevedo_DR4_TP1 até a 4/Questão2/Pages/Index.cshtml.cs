using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Questão2.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
