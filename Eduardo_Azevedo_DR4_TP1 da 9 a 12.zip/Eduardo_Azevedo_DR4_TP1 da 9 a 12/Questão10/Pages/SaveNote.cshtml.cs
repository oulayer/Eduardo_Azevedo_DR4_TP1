using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Hosting;
using System.ComponentModel.DataAnnotations;

namespace Questao10.Pages
{
    public class SaveNoteModel : PageModel
    {
        private readonly IWebHostEnvironment _environment;

        public SaveNoteModel(IWebHostEnvironment environment)
        {
            _environment = environment;
        }

        public class InputModel
        {
            public string Content { get; set; } = "";
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public string? SavedFileName { get; set; }

        public async Task OnPostAsync()
        {
            string folder = Path.Combine(_environment.WebRootPath, "files");

            Directory.CreateDirectory(folder);

            string fileName = $"note-{DateTime.UtcNow:yyyyMMddHHmmssfff}.txt";

            string filePath = Path.Combine(folder, fileName);

            await System.IO.File.WriteAllTextAsync(filePath, Input.Content);

            SavedFileName = fileName;
        }
    }
}