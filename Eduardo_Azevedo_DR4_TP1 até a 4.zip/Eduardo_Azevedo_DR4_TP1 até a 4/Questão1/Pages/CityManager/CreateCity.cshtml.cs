using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SeuProjeto.Pages.CityManager;

public class CreateCityModel : PageModel
{
    [BindProperty]
    public string CityName { get; set; } = string.Empty;

    public string SubmittedCityName { get; set; } = string.Empty;

    public void OnGet()
    {
    }

    public void OnPost()
    {
        SubmittedCityName = CityName;
    }
}