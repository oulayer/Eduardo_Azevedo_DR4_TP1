using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace Questao3.Pages.CityManager
{
    public class CreateCityModel : PageModel
    {
        public class InputModel
        {
            [Required(ErrorMessage = "O nome da cidade é obrigatório.")]
            [MinLength(3, ErrorMessage = "O nome precisa ter pelo menos 3 caracteres.")]
            public string CityName { get; set; } = "";
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public string SubmittedCityName { get; set; } = "";

        public void OnGet()
        {
        }

        public void OnPost()
        {
            if (ModelState.IsValid)
            {
                SubmittedCityName = Input.CityName;
            }
        }
    }
}