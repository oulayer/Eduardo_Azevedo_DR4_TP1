using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace Questao12.Pages.CountryManager
{
    public class CreateCountryModel : PageModel
    {
        public class InputModel
        {
            [Required(ErrorMessage = "O nome do país é obrigatório.")]
            public string CountryName { get; set; } = "";

            [Required(ErrorMessage = "O código do país é obrigatório.")]
            public string CountryCode { get; set; } = "";
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public string Message { get; set; } = "";

        public void OnGet()
        {
        }

        public void OnPost()
        {
            if (!string.IsNullOrWhiteSpace(Input.CountryName) &&
                !string.IsNullOrWhiteSpace(Input.CountryCode))
            {
                if (char.ToUpperInvariant(Input.CountryName.Trim()[0]) !=
                    char.ToUpperInvariant(Input.CountryCode.Trim()[0]))
                {
                    ModelState.AddModelError(
                        "Input.CountryCode",
                        "O nome do país e o código devem começar com a mesma letra."
                    );
                }
            }

            if (ModelState.IsValid)
            {
                Message = "País cadastrado com sucesso!";
            }
        }
    }
}