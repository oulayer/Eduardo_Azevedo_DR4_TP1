using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Hosting;

namespace Questao11.Pages
{
    public class ReadNotesModel : PageModel
    {
        private readonly IWebHostEnvironment _environment;

        public ReadNotesModel(IWebHostEnvironment environment)
        {
            _environment = environment;
        }

        public List<string> Files { get; set; } = new();

        public string? SelectedFileName { get; set; }

        public string? FileContent { get; set; }

        public async Task OnGetAsync(string? fileName)
        {
            string folder = Path.Combine(_environment.WebRootPath, "files");

            Directory.CreateDirectory(folder);

            Files = Directory.GetFiles(folder)
                .Where(file => Path.GetExtension(file) == ".txt")
                .Select(file => Path.GetFileName(file))
                .OrderBy(file => file)
                .ToList();

            if (!string.IsNullOrEmpty(fileName))
            {
                string safeFileName = Path.GetFileName(fileName);

                if (safeFileName != fileName ||
                    Path.GetExtension(safeFileName) != ".txt")
                {
                    return;
                }

                string filePath = Path.Combine(folder, safeFileName);

                if (System.IO.File.Exists(filePath))
                {
                    SelectedFileName = safeFileName;

                    FileContent = await System.IO.File.ReadAllTextAsync(filePath);
                }
            }
        }
    }
}